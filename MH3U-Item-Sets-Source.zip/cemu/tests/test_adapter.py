from test_ui import main

if __name__ == "__main__":
    main()
